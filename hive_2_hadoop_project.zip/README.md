# hadoop_dump
Reading material and error images, encountered so far.
##To read
(opennlp) [http://opennlp.apache.org/documentation/1.6.0/manual/opennlp.html]

(apache lucene) [http://www.tutorialspoint.com/lucene/lucene_environment.html] 
